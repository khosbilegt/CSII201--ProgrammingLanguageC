/*

#include <stdio.h>

int main() {
    
    int n, k = 0, m;
    
    printf("Input number of elements: ");
    scanf ("%d", &n);
    
    int a[n];
    
    while (k != n) {
        m = k + 1;
        printf("Input %dth number:", m);
        scanf("%d", &a[k]);
        printf("%dth number is: %d\n", m, a[k]);
        k++;
    }
    
    
    while (k != 0) {
        k --;
        printf("%d ", a[k]);
    }
    
}
*/
