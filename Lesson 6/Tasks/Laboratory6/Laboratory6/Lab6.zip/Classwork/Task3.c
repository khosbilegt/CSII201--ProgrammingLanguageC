/*
#include <stdio.h>

int main() {
    int n, m, g;
    
    printf("Enter n: ");
    scanf("%d", &n);
    printf("Enter m: ");
    scanf("%d", &m);
    printf("n = %d, m = %d\n", n, m);
    
    if (n >= 1 && m < 100) {
        g = n + m;
        int a[n], b[m], c[g], k = 0, l = 0, y, z, v = 0, f = 0;
        
        printf("A array: \n");
        while (k != n) {
            y = k + 1;
            scanf("%d", &a[k]);
            k++;
        }
        
        printf("B array: \n");
        while (l != m) {
            z = l + 1;
            scanf("%d", &b[l]);
            l++;
        }
        
        printf("C: ");
        while (v != n) {
            c[v] = a[v];
            printf("%d ", c[v]);
            v ++;
        }
        
        while (f != m) {
            c[n+f] = b[f];
            printf("%d ", c[n+f]);
            f++;
        }
        
        printf("\n");
        
    } else {
        printf("Must be n >= 1 and m < 100\n");
    }
}
*/
