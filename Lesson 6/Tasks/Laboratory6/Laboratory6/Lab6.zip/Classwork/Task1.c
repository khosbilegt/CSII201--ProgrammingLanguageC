/*
#include <stdio.h>

int main() {
    int a[10];
    int i = 0;
    
    for (i = 0; i != 10; i++) {
        int k = i + 1;
        a[i] = k;
        printf("%dth number: %d\n", k, a[i]);
    }
}
*/
