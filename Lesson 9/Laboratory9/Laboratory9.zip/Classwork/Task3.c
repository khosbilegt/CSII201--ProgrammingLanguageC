/*
#include <stdio.h>
int max(int a[], int n);

int main() {
    int a[] = {3, 4, 5, 2, 0, 5, 6, 7, 8}, n, maximum;
    printf("Please input the number of elements: ");
    scanf("%d", &n);
    
    maximum = max(a, n);
    printf("%d\n", maximum);
}

int max(int a[], int n) {
    int most = 0;
    for (int x = 0; x < n; x++) {
        if (most <= a[x]) {
            most = a[x];
        }
    }
    
    return most;
}
*/
