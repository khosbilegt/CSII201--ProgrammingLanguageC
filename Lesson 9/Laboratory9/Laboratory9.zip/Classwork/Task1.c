/*
#include <stdio.h>
int isEven(int);

int main() {
    int x;
    printf("Enter number: ");
    scanf("%d", &x);
    
    int output = isEven(x);
    printf("%d\n", output);
    
}

int isEven(int x) {
    if (x % 2 == 0) {
        return 1;
    } else {
        return 0;
    }
}
*/
