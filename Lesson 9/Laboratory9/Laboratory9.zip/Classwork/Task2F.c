
#include <stdio.h>
void readArr(int A[], int n);
void printArr(int A[], int n);

int main() {
    int a[100], n;
    
    printf("Input number of elements: ");
    scanf("%d", &n);
    
    readArr(a, n);
    printArr(a, n);
}


void readArr(int A[], int n) {
    for (int i = 0; i < n; i++) {
        printf("Enter %dth number: ", i + 1);
        scanf("%d", &A[i]);
    }
}

void printArr(int A[], int n) {
    for (int i = 0; i < n; i++) {
        printf("%dth element is: %d\n", i + 1, A[i]);
    }
    printf("\n");
}
