/*
#include <stdio.h>
int power (int a, int b); // #1: Declare hiigeegui
                          // #2: int butsaah yostoi

int main() {
    int n, a;
    
    // #3: Salgaj, iluu oilgomjtoi bolgoson.
    scanf("%d", &a);
    scanf("%d", &n);
    
    printf("%d\n", power(a, n));
    
    scanf("%d", &a);
    scanf("%d", &n);
    
    printf("%d\n", power(a, n));
}

int power(int a, int b) {
    int i;
    int t = 1; // Function-aas gadna baival utga ni reset hiigdehgui tul 2 dah udaad
               // aldaatai garna.
    for (i = 1; i <= b; i++) {
        t *= a;
    }
    return t;
}
*/
