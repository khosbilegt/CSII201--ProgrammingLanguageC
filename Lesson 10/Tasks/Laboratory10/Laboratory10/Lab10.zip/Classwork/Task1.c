/*
#include <stdio.h>

int count(char s[]);
int main() {
    char word[100];
    printf("Enter word: ");
    scanf("%s", word);
    printf("%s\n", word);
    int vowel = count(word);
    printf("Number of Vowels: %d\n", vowel);
}

int count(char s[]) {
    int m = 0;
    for(int i = 0; i < 100; i++) {
        if (s[i] == 'A' || s[i] == 'a' || s[i] == 'E' || s[i] == 'e' || s[i] == 'I' || s[i] == 'i' || s[i] == 'O' || s[i] == 'o' || s[i] == 'U' || s[i] == 'u') {
            m = m + 1;
        }
    }
    return m - 1;
}
*/
