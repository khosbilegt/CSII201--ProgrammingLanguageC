/*
#include <stdio.h>
#include <string.h>

int main() {
    char word1[100], word2[100];
    
    printf("Enter Word 1: ");
    scanf("%s", word1);
    printf("Enter Word 2: ");
    scanf("%s", word2);
    
    if (strcmp(word1, word2) == 0) {
        printf("Same Word\n");
    } else {
        printf("Not the same word\n");
    }
}

*/
