/*
#include <stdio.h>

int main() {
    char arr[100];
    int check, vowel = 0;
    
    printf("Enter array of characters: ");
    scanf("%s", arr);
    
    for (check = 0; check < 100; check++) {
        if (arr[check] == 'A' || arr[check] == 'a' || arr[check] == 'E' || arr[check] =='e' || arr[check] == 'I' || arr[check] == 'I' || arr[check] == 'O' || arr[check] == 'o' || arr[check] == 'U' || arr[check] == 'u') {
            
            vowel = vowel + 1;
            
        }
    }
    
    printf("Number of vowels: %d\n", vowel);
}
*/
