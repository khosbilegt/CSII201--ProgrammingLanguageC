/*
#include <stdio.h>

int main() {
    int i; // i zarlaagui baisan
    char s[] = "hello";
    char s2[] = "Muis-iinhan";
    
    int length = sizeof(s2)/sizeof(s2[0]); //s2 - iin urtiig ashiglah yostoi
    
    for (i = 0; i < length; i++) { //s1 - iin urtiig s2 - iin urtaar solison
        s2[i] = s[i];
    }
    
    printf("%s\n", s2);
    return 0;
}
*/
