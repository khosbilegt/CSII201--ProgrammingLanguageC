/*
#include <stdio.h>

int main() {
    char arr[100];
    
    printf("Enter sentence: ");
    scanf("%[^'\n']s", arr);
    printf("%s\n", arr);
}
*/
