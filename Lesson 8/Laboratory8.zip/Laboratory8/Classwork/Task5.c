#include <stdio.h>
/*
int main() {
    char arr1[] = "abcd";
    char arr2[] = "xyz";
    int i = 0;
    
    int length1 = sizeof(arr1)/sizeof(arr1[0]) - 1;
    int length2 = sizeof(arr2)/sizeof(arr2[0]) - 1;
    while (i < length2) {
        arr1[length1] = arr2[i];
        length1++;
        i++;
    }
    
    printf("%s\n", arr1);
}
*/
