/*
#include <stdio.h>

int main() {
    char arr[100];
    int i, wordCount = 1;
    printf("Enter sentence: ");
    scanf("%[^'\n']s", arr);
    printf("%s\n", arr);
    
    for (i = 0; i < 100; i++) {
        if (arr[i] == ' ') {
            wordCount++;
        }
    }
    
    printf("Word Count: %d\n", wordCount);
}
*/
