/*
#include <stdio.h>
void readArr(int *p);
int main() {
    int a[100];
    for (int i = 0; i < 4; i++) {
        readArr(a + i - 2);
    }
    for(int i = 0; i < 4; i++) {
        printf("%d ", *(a + i));
    }
    printf("\n");
}
void readArr(int *p) {
    scanf("%d", p + 2);
}
*/
