/*
#include <stdio.h>
void readArr(int *begin, int *end);
void printArr(int *begin, int *end);
int main() {
    int a[100];
    readArr(a, a + 5);
    printArr(a, a + 5);
    printf("\n");
}
void readArr(int *begin, int *end) {
    for (int i = 0; i < 5; i++) {
        scanf("%d", begin + i);
    }
}
void printArr(int *begin, int *end) {
    for (int i = 0; i < 5; i++) {
        printf("%d ", *(begin + i));
    }
}
*/
