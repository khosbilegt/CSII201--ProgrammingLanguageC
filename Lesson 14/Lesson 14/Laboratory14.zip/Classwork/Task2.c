/*
#include <stdio.h>
long int size(int *begin, int *end);
int main() {
    int n;
    scanf("%d", &n);
    int a[n];
    printf("%d\n", size(a, a + n));
    return 0;
}
long int size(int *begin, int *end) {
    long int result = end - begin;
    return result;
}
*/
