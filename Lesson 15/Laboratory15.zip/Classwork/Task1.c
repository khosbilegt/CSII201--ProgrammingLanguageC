/*
#include <stdio.h>
int main() {
    FILE *file;
    int n1, n2;
    file = fopen("input.txt", "r+");
    fscanf(file, "%d %d", &n1, &n2);
    fclose(file);
    int result = n1 - n2;
    printf("Number 1: %d\n", n1);
    printf("Number 2: %d\n", n2);
    printf("Result: %d\n", result);
    return 0;
}
*/
