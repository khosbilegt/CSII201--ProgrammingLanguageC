/*
#include <stdio.h>

int main() {
    int x;
    int *address = &x;
    scanf("%d", address);
    printf("%d\n", x);
    return 0;
}
*/
