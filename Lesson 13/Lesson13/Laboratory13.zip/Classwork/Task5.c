/*
#include <stdio.h>

struct Triangle {
    int a, b, c;
};
void readTriangle(struct Triangle *g);

int main() {
    struct Triangle g;
    readTriangle(&g);
    printf("%d %d %d\n", g.a, g.b, g.c);
}
void readTriangle(struct Triangle *g) {
    printf("Enter a: ");
    scanf("%d", &g->a);
    printf("Enter b: ");
    scanf("%d", &g->b);
    printf("Enter c: ");
    scanf("%d", &g->c);
}

*/
