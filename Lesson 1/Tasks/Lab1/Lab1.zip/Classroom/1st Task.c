#include <stdio.h>

int main()
{
    printf("Сайн байна уу? Си Хэл\n");
    return 0;
}

