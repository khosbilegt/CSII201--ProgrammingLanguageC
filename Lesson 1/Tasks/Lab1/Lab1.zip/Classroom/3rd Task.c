#include "stdio.h"

int main()
{
    int y = 2002, m = 8, d = 1;
    
    printf("Би %d оны %d сарын %d-ны өдөр төрсөн.\n", y, m, d);
    return 0;
}
