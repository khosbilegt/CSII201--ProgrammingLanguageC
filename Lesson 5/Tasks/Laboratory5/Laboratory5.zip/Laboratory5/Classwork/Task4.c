#include <stdio.h>

int main()
{
    int x = 0, n;
    
    printf("Input number: ");
    scanf("%d", &n);
    
    while (x <= n) {
        printf("%.*s\n", x, "xxxxxxxxxxxxxxx");
        x ++;
    }
}
