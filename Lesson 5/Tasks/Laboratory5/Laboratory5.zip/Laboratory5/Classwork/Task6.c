#include <stdio.h>

int main() {
    
    int n, m = 0, k;
    
    printf("Input number: ");
    scanf("%d", &n);
    
    while (m <= n) {
        printf("%.*s\n", m, "xxxxxxxxxxxxxxx");
        m ++;
    }
    
    k = m - 2;
    
    while (k > 0) {
        printf("%.*s\n", k, "xxxxxxxxxxxxxxx");
        k --;
    }
    
}
