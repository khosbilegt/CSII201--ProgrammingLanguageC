#include <stdio.h>

int main() {
    int n;
    
    printf("Input number: \n");
    scanf("%d", &n);
    
    switch (n % 2) {
        case 0:
            printf("Tegsh\n");
            break;
        case 1:
            printf("Sondgoi\n");
            break;
    }
}
