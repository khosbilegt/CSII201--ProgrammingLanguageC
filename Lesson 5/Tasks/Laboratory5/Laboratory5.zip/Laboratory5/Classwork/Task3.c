#include <stdio.h>

int main() {
    int x = 1;
    
    while (x <= 10) {
        int table[2] = {x, x * 10};
        printf("%d %d\n", table[0], table[1]);
        x ++;
    }
}
