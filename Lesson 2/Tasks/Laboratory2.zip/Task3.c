#include <stdio.h>

int main() {
    int a, b, c;
    a = 3;
    b = 10;
    c = 8;
    c < b && a < c && printf("bolj ");
   (a % 3 == 0 || c % 5 == 3) && printf("bna.\n");
    
    // a = 3-t huvaagddag, c-ees baga too.
    // b = c-ees ih baival yamar ch baisan bolno.
    // c = 5-t huvaagdaad 3 gardag too, a-ees ih, b-ees baga too.
    return 0;
 }
 

