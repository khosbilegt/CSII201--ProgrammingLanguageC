/*
#include <stdio.h>

int main() {
    
    int n, i;
    printf("input something: \n");
    scanf("%d", &n);
    
    do {
        printf("%d", i);
        i ++; // <-- Eniig nemeh heregtei.
    } while (i < n);
    
    // Uchir ni i hezee ch uurchlugduhgui bol i < n bish nuhtsul hezee ch burdehgui. Herev oruulsan
    // toog uuriig ni oruulahiig husvel < operator-iig <= gej bichij bolno.
    
    printf("\n");
    return 0;
}
*/
