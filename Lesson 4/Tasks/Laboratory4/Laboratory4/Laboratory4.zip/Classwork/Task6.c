/*
#include <stdio.h>
int main()
{
   int x, y, z = 0, d;

   printf("Enter number: ");
   scanf("%d", &x);

   y = x;

   while (y != 0)
   {
      d = y % 10;
      z = z + d;
      y = y / 10;
   }

   printf("Sum = %d\n", z);

   return 0;
}
*/
