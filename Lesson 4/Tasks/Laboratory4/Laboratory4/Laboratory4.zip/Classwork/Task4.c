/*
 #include <stdio.h>

int main()
{
    int x, y, z = 0;

    printf("Enter number: ");
    scanf("%d", &y);

    for(x=2; x<=y; x+=2)
    {
        z += x;
    }

    printf("Sum of even numbers = %d\n", z);

    return 0;
}
*/
