/*
#include <stdio.h>

int main() {
    int n, i;
    
    scanf("%d", &n);
    for (i = 1; i <= n; n--) {
        
        printf("%d ", n);
        
    } printf("\n");
    return 0;
}
*/
