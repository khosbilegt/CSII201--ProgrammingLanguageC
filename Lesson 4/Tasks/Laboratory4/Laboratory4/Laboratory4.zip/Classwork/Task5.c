/*
#include <stdio.h>

int main() {

    int c, f;
    float f2 = 32;
    
    printf("Input Celsius: ");
    scanf("%d", &c);
    
    f = 1.8 * c + 32;
    
    while (f2 <= f) {
        printf("%f\n", f2);
        f2 = f2 + 1.8;
    }
 return 0;
}
*/
