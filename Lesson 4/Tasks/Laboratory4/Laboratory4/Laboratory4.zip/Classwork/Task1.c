/*
#include <stdio.h>

int main() {
    int n, p;
    p = 0;
    printf("Enter Number:\n");
    scanf("%d", &n);
    
    do {
        printf("Programming in C\n");
        p ++;
    } while (p < n);
}

*/
