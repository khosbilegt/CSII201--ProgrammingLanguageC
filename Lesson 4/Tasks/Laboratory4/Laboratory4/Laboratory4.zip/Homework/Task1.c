/*
#include <stdio.h>
 
int main() {
 
    int x, y;
 
    printf("Input an integer: ");
 
    scanf("%d", &x);
 
    printf("Divisors: ");
 
    for(y = 1; y <= x; y++) {
 
        if((x % y) == 0){
            printf("%d\n", y);
 
        }
    }
 
    return 0;
}
*/
