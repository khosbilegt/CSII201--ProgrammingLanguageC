/*
#include <stdio.h>

int main() {
    
    int x, y, z, divisor;
    
    printf("Enter number 1: ");
    scanf("%d", &x);
    
    printf("Enter number 2: ");
    scanf("%d", &y);
    
    for (z = 1; z <= x && z <= y; ++z) {
        
        divisor = z;
        
    }
    
    printf("Divisor: %d\n", divisor);
    return 0;
}
*/
