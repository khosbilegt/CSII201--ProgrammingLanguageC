/*
#include <stdio.h>

int main() {
    int n, m, sent, sent2, num = 0;
    
    printf("Enter number of columns: ");
    scanf("%d", &n);
    printf("Columns: %d\n", n);
    
    printf("Enter number of rows: ");
    scanf("%d", &m);
    printf("Rows: %d\n", m);
    
    int arr[n][m];
    
    for (sent = 0; sent < m; sent++) {
        num = num + 1;
        
        for (sent2 = 0; sent2 < n; sent2++) {
            printf("%d ", num);
        }
        printf("\n");
    }
}
*/
