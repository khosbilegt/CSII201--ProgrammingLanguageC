/*
#include <stdio.h>

int main() {
    int n, sent, sent2, d = 0;
    
    printf("Input n: ");
    scanf("%d", &n);
    printf("Size %dx%d\n", n, n);
    
    for (sent = 0; sent < n; sent++) {
        int check = 1 + d;
        for (sent2 = 0; sent2 < n; sent2++) {
            printf("%d ", check);
            check = check + 1;
        }
        printf("\n");
        d ++;
    }
    
}
*/
