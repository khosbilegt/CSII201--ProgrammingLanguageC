/*
#include <stdio.h>

void readArr(int r, int c, int arr[r][c]);
void printArr(int r, int c, int arr[r][c]);

int main() {
    int r, c;
    scanf("%d", &r);
    scanf("%d", &c);
    int arr[r][c];
    readArr(r, c, arr);
    printf("--------\n");
    printArr(r, c, arr);
}

void readArr(int r, int c, int arr[r][c]) {
    for(int i = 0; i < r; i++) {
        for (int j = 0; j < c; j++) {
            printf("%d %d: ", i, j);
            scanf("%d", &arr[i][j]);
        }
    }
}

void printArr(int r, int c, int arr[r][c]) {
    for(int i = 0; i < r; i++) {
        for (int j = 0; j < c; j++) {
            printf("%d %d: %d\n", i, j, arr[i][j]);
        }
    }
}
*/
