#include <stdio.h>

int main() {
    int a, b;
    
    /*
    if (a == b); <--- End baigaa ; avj hayah heregtei.
    printf("tentsuu\n");
    else
    printf("yalgaatai\n");
    */
    
  
    if (a == b)
        printf("tentsuu\n");
    else
        printf("yalgaatai\n");
}
